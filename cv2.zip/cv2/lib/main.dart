import 'package:cv2/pages/home.dart';
import 'package:cv2/theme/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:cv2/pages/introduction.page.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'pages/langue/langue_.dart';

void main() {
    Langue _language = Langue();
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences.getInstance().then((instance) {
    String language = instance.getString('language') ?? 'FR';
    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => ThemeProvider()),
          ChangeNotifierProvider(create: (_) => Langue()..setLangue(language)),
        ],
        child: const MyApp(),
      ),
    );
  });
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: const PageHome(),
        theme: Provider.of<ThemeProvider>(context).themeData,
      ),
    );
  }
}
