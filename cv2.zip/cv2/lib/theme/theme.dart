import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

ThemeData lightMode = ThemeData(
  brightness: Brightness.light,
  colorScheme: ColorScheme.light(
    background: Colors.white,
    primary: Colors.pink[900]!, // Couleur rose foncé pour le thème clair
    secondary: Colors.purpleAccent.shade400, // Couleur violette accentuée pour le thème clair
    tertiary: Colors.deepPurple.shade900, // Couleur pourpre foncé pour le thème clair
  ),
);

ThemeData darktMode = ThemeData(
  brightness: Brightness.dark,
    colorScheme: ColorScheme.dark(
  background:Colors.black,
  primary:const Color.fromRGBO(66, 66, 66, 1),
  secondary:Colors.grey.shade600,
  tertiary: Colors.grey.shade200,),
);

