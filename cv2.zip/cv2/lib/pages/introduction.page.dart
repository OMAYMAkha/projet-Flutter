/*import 'package:flutter/material.dart';
//import 'package:introduction_screen/introduction_screen.dart';
import 'package:provider/provider.dart';
import 'package:cv2/pages/home.dart';
import 'package:cv2/pages/langue/langue_.dart';
import 'package:cv2/theme/theme_provider.dart';

class Intro extends StatelessWidget {
  const Intro({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IntroductionScreen(
        pages: [
          // Page 1
          PageViewModel(
            image: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 100.0,
                    backgroundImage: AssetImage('images/profile.png'),
                  ),
                ),
              ],
            ),
            decoration: PageDecoration(
              pageColor: Theme.of(context).colorScheme.background,
              titleTextStyle: TextStyle(
                color: Theme.of(context).colorScheme.tertiary,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              bodyTextStyle: TextStyle(
                color: Theme.of(context).colorScheme.tertiary,
                fontSize: 18,
              ),
            ),
            title: 'Iben khalifa Omayma',
            body: Provider.of<Langue>(context).introt_page1(),
          ),
          // Page 2
          PageViewModel(
            decoration: PageDecoration(
              pageColor: Theme.of(context).colorScheme.background,
              titleTextStyle: TextStyle(
                color: Theme.of(context).colorScheme.tertiary,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              bodyTextStyle: TextStyle(
                color: Theme.of(context).colorScheme.tertiary,
                fontSize: 18,
              ),
            ),
            image: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FlutterLogo(size: 150), // Logo Flutter
                      SizedBox(width: 10),
                      Image.asset('images/dartlogo.png', width: 135),
                    ],
                  ),
                ],
              ),
            ),
            title: Provider.of<Langue>(context).introt_page2t(),
            body: Provider.of<Langue>(context).introt_page2b(),
          ),
          // Page 3
          PageViewModel(
            decoration: PageDecoration(
              titleTextStyle: TextStyle(
                color: Theme.of(context).colorScheme.tertiary,
                fontSize: 70,
                fontWeight: FontWeight.bold,
              ),
              bodyTextStyle: TextStyle(
                fontSize: 18,
              ),
            ),
            title: '',
            bodyWidget: Column(
              children: [
                  Icon(
                  Icons.settings,
                  size: 80,
                ),
                SizedBox(height: 20),
                Text(
                  Provider.of<Langue>(context).introt_page3b(),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18), 
                ),
              
              ],
            ),
            footer: Column(
              children: [
                LanguageSelection(), 
                SizedBox(height: 10),
                ThemeModeToggle(),
                SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => goToHome(context),
                  child: Text('Accueil'),
                ), 
              ],
            ),
          ),
        ],
        next: Icon(Icons.arrow_forward),
        done: const Text('Start'),
        onDone: () => goToHome(context),
        showSkipButton: true,
        skip: Text('Ignorer'),
        dotsDecorator: getDotDecoration(),
        nextFlex: 0,
        skipOrBackFlex: 0,
        animationDuration: 500,
      ),
    );
  }

  DotsDecorator getDotDecoration() {
    return DotsDecorator(
      color: Colors.grey,
      size: Size(10, 10),
      activeSize: Size(22, 10),
      activeColor: Colors.blue,
      activeShape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
    );
  }

  void goToHome(context) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const PageHome()),
    );
  }
}

class LanguageSelection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      title: Text(
        Provider.of<Langue>(context).dt_Choisirlalangue(),
      ),
      leading: Icon(Icons.language),
      children: [
        ListTile(
          leading: Image.asset('images/francais.png', width: 30, height: 30),
          title: Text('FR'),
          onTap: () {
            Provider.of<Langue>(context, listen: false).setLangue('FR');
          },
        ),
        ListTile(
          leading: Image.asset('images/anglais.png', width: 30, height: 30),
          title: Text('EN'),
          onTap: () {
            Provider.of<Langue>(context, listen: false).setLangue('EN');
          },
        ),
      ],
    );
  }
}

class ThemeModeToggle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(Icons.brightness_6),
      title: Text(
        Provider.of<Langue>(context).dt_Mode_sombre_clair(),
      ),
      trailing: Switch(
        value: Theme.of(context).brightness == Brightness.dark,
        onChanged: (value) {
          Provider.of<ThemeProvider>(context, listen: false).toggletheme();
        },
      ),
    );
  }
}*/
