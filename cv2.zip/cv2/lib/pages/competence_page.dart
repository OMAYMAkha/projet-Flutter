import 'package:cv2/pages/langue/langue_.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ChangeNotifierProvider(
        create: (context) => Langue(), 
        child: CompetencePage(),
      ),
    );
  }
}

class CompetencePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Langue langue = Provider.of<Langue>(context);

    final List<Competence> competences = [
    /*Competence(
        title: langue.ct_Procedures_Douanieres(),
        description: [
          langue.ct_Controle_documentaire(),
          langue.ct_Classification_tarifaire(),
          langue.ct_Calculer_droits_taxes(),
          langue.ct_Detecter_infractions(),
          langue.ct_Conseiller_assister_operateurs(),
        ],
        imagePath: 'images/douane_icone.png',
      ),*/
      Competence(
        title: langue.ct_Reseaux_informatique(),
        description: [
          langue.ct_Configuration_gestion_reseaux(),
          langue.ct_Protocoles_routage(),
          langue.ct_Reseaux_LAN_WAN(),
          langue.ct_Securite_reseau(),
          langue.ct_Adressage_IP_subnetting(),
        ],
        imagePath: 'images/reseau-local.png',
      ),
      Competence(
        title: langue.ct_Depannage(),
        description: [
          langue.ct_Depannage_materiel_logiciel(),
          langue.ct_Installation_configuration_systemes_exploitation(),
          langue.ct_Maintenance_materiel_informatique(),
          langue.ct_Support_utilisateurs(),
        ],
        imagePath: 'images/depannage.png',
      ),
      Competence(
        title: langue.ct_Development(),
        description: [
          langue.ct_Developpement_logiciels(),
          langue.ct_Developpement_web(),
          langue.ct_Developpement_mobiles(),
        ],
        imagePath: 'images/developpement_dapplications.png',
      ),
      Competence(
        title: langue.ct_Base_de_donnees(),
        description: [
         // langue.ct_Modelisation_donnees(),
          langue.ct_SQL(),
          langue.ct_Traitement_donnees_massive(),
        ],
        imagePath: 'images/protection-des-donnees.png',
      ),
      Competence(
        title: langue.ct_Administration_System(),
        description: [
          langue.ct_Gestion_systemes_exploitation(),
          langue.ct_Installation_configuration_serveurs(),
          langue.ct_Securite_informatique(),
          langue.ct_Virtualisation_cloud_computing(),
        ],
        imagePath: 'images/administration.png',
      ),
      Competence(
        title: langue.ct_Langue(),
        description: [
          langue.ct_Arabe(),
          langue.ct_Francais(),
          langue.ct_Anglais(),
        ],
        imagePath: 'images/langues.png',
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          langue.cp_Skills(),
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: CompetencePageView(competences: competences),
    );
  }
}

class CompetencePageView extends StatefulWidget {
  final List<Competence> competences;

  CompetencePageView({required this.competences});

  @override
  _CompetencePageViewState createState() => _CompetencePageViewState();
}

class _CompetencePageViewState extends State<CompetencePageView> {
  int _selectedCompetenceIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 100,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: widget.competences.length,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedCompetenceIndex = index;
                  });
                },
                child: Container(
                  margin: EdgeInsets.all(8.0),
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _selectedCompetenceIndex == index
                        ? Colors.blue
                        : Colors.grey[300],
                    border: _selectedCompetenceIndex == index
                        ? Border.all(color: Colors.black, width: 3)
                        : null,
                  ),
                  child: Image.asset(
                    widget.competences[index].imagePath,
                    width: 40,
                    height: 40,
                    //color: Colors.white,
                  ),
                ),
              );
            },
          ),
        ),
        Expanded(
          child: AnimatedSwitcher(
            duration: Duration(milliseconds: 500),
            child: _selectedCompetenceIndex != -1
                ? _buildCompetenceDetail(widget.competences[_selectedCompetenceIndex])
                : Center(child: Text('')),
          ),
        ),
      ],
    );
  }

  Widget _buildCompetenceDetail(Competence competence) {
    return Container(
      key: ValueKey(competence.title),
      padding: EdgeInsets.all(16),
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(
            competence.imagePath,
            width: 50,
            height: 50,
          ),
          SizedBox(height: 8),
          Text(
            competence.title,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold,color: Colors.black),
          ),
          SizedBox(height: 8),
          ListView(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            children: competence.description
                .map((desc) => ListTile(
                      leading: Icon(Icons.check_circle, color: Theme.of(context).colorScheme.primary),
                      title: Text(desc,style: TextStyle(color: Colors.black),),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}

class Competence {
  final String title;
  final List<String> description;
  final String imagePath;

  Competence({required this.title, required this.description, required this.imagePath});
}
