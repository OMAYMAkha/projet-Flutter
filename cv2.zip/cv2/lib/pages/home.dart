import 'package:flutter/material.dart';
import 'package:cv2/pages/MyDrawer.page.dart';
import 'package:cv2/pages/home_page.dart';
import 'package:cv2/pages/education_page.dart';
import 'package:cv2/pages/experience_page.dart';
import 'package:cv2/pages/competence_page.dart';
import 'package:cv2/pages/bottom_navigation_bar.dart';

class PageHome extends StatefulWidget {
  const PageHome({Key? key}) : super(key: key);

  @override
  _PageHomeState createState() => _PageHomeState();
}

class _PageHomeState extends State<PageHome> {
  late PageController _pageController;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _selectedIndex);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onTabChanged(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _pageController.animateToPage(
      index,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(),
      body: AnimatedSwitcher(
        duration: Duration(milliseconds: 500),
        child: PageView.builder(
          controller: _pageController,
          onPageChanged: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          itemCount: 5, // Nombre total de pages
          itemBuilder: (context, index) {
            switch (index) {
              case 0:
                return HomePage();
              case 1:
                return EducationPage();
              case 2:
                return ExperiencePage();
              case 3:
                return CompetencePage();
              //default:
                //return HomePage(); 
            }
          },
        ),
        switchInCurve: Curves.easeIn,
        switchOutCurve: Curves.easeOut,
        transitionBuilder: (Widget child, Animation<double> animation) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
      ),
      bottomNavigationBar: BottomNavigationBarWidget(
        selectedIndex: _selectedIndex,
        onTabChanged: _onTabChanged,
      ),
    );
  }
}
