import 'package:cv2/pages/langue/langue_.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class EducationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          Provider.of<Langue>(context).ep_Parcours_educatif(),
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          _buildEducation(
            context,
            Provider.of<Langue>(context).ep_Master_pro(),
            Provider.of<Langue>(context).ep_Institut_Sfax(),
            Provider.of<Langue>(context).ep_En_cours(),
            AssetImage('images/iset_logo.png'),
          ),
          /*SizedBox(height: 16),
          _buildEducation(
            context,
            Provider.of<Langue>(context).ep_Formation_douaniere(),
            Provider.of<Langue>(context).ep_Ecole_Nationale_Douanes(),
            '2016',
            AssetImage('images/douane_logo.png'),
          ),
          SizedBox(height: 16),
          _buildEducation(
            context,
            Provider.of<Langue>(context).ep_Formation_Militaire(),
            Provider.of<Langue>(context).ep_Academie_Militaire(),
            '2015',
            AssetImage('images/academie_logo.png'),
          ),*/
          SizedBox(height: 16),
          _buildEducation(
            context,
            Provider.of<Langue>(context).ep_Licence_administration(),
            Provider.of<Langue>(context).ep_Institut(),
            '2023',
            AssetImage('images/isecs_logo.png'),
          ),
          SizedBox(height: 16),
          _buildEducation(
            context,
            Provider.of<Langue>(context).ep_Baccalaureat_informatique(),
            Provider.of<Langue>(context).ep_Lycee(),
            '2020',
            AssetImage('images/bac_logo.png'),
          ),
        ],
      ),
    );
  }

  Widget _buildEducation(BuildContext context, String title, String institution, String year, AssetImage? institutionLogo) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 30,
              backgroundImage: institutionLogo,
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    institution,
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    year,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
