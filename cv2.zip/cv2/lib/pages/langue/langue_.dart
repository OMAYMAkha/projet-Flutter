import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Langue with ChangeNotifier {
  String _lang = 'FR';

  String get lang => _lang;

  void setLangue(String lang) {
    _lang = lang;
    notifyListeners();
  }

  String dt_Choisirlalangue() {
    return _lang == 'FR' ? "Choisir la langue" : "Choose language";
  }

  String dt_Mode_sombre_clair() {
    return _lang == 'FR' ? "Mode sombre/clair" : "Dark mode/light mode";
  }

  String dt_Telephone() {
    return _lang == 'FR' ? "Telephone" : "Phone";
  }

  String dt_Adresse() {
    return _lang == 'FR' ? "Adresse" : "Address";
  }


  String ht_Officier_douane() {
    return _lang == 'FR' ? "Technicienne Informatique" : "Customs Officer";
      }
  String ht_douane() {
    return _lang == 'FR' ? "developpeuse" : "Customs";
  }
  
  String ht_reseaux() {
    return _lang == 'FR' ? "Reseaux" : "Networks";
  }
  String ht_dev() {
    return _lang == 'FR' ? "Dév" : "Coding";
  }

  String ht_Bienvenue_sur_Mon_CV() {
    return _lang == 'FR' ? "Bienvenue sur Mon CV" : "Welcome to My CV";
  }

  String ht_Resume_Professionnel() {
    return _lang == 'FR' ? "Resumé Professionnel" : "Professional Summary";
  }
String ht_Comp_Resume_Professionnel() {
  return lang == 'FR'
      ? "Développeur informatique passionné et expérimenté, spécialisé dans le développement d'applications web utilisant Angular pour le front-end et Spring Boot pour le back-end. Fort de plusieurs années d'expérience dans la conception, le développement et le déploiement d'applications robustes et évolutives, je possède une solide maîtrise des technologies modernes et des meilleures pratiques de développement."
      : "Passionate and experienced software developer specializing in web application development using Angular for the front-end and Spring Boot for the back-end. With several years of experience in designing, developing, and deploying robust and scalable applications, I have a strong mastery of modern technologies and best development practices.";  }
  String ht_Competences_Cles() {
    return _lang == 'FR' ? "Compétences Clés" : "Key Skills";
  }

  String ht_Certificats() {
    return _lang == 'FR' ? "Certificats" : "Certificates";
  }

  String ht_Projets_Recents() {
    return _lang == 'FR' ? "Projets Récents" : "Recent Projects";
  }
  
  String ht_compt_Projets_Recents() {
    return _lang == 'FR' ? "Taper sur le logo pour consulter mon compte GitHub" : "Tap  the logo to view my GitHub account";
  }
    String Bt_accueil() {
    return _lang == 'FR' ? "Accueil" : "Home";
  }
      String Bt_competences() {
    return _lang == 'FR' ? "Competences" : "Skills";
  }
  String et_Experience_Professionnelle() {
    return _lang == 'FR' ? "Expérience Professionnelle" : "Professional Experience";
  }

  String et_IT() {
    return _lang == 'FR' ? "technicienne Informatique" : "IT technician";
  }

  String et_informatique_deve() {
    return _lang == 'FR' ? "developpeuse informatique" : "IT developer";
  }

  String et_juin_2023_novembre2023() {
    return _lang == 'FR' ? "juin 2023 - novembre 2023" : "June 2023 - November 2023";
  }

  String et_Description_travaile() {
    return _lang == 'FR' ? "Analyser les besoins des utilisateurs et proposer des solutions techniques adaptées.Concevoir, développer et maintenir des applications et logiciels conformément aux spécifications." : "Analyze user needs and propose appropriate technical solutions.Design, develop and maintain applications and software according to specifications..";
  }

  String et_Stagiaire_PFE() {
    return _lang == 'FR' ? "Stagiaire pour PFE" : "Intern for PFE";
  }

  String et_KMF_Bussines_solution() {
    return _lang == 'FR' ? "KMF Bussines Solutions Sfax" : "KMF Bussines Solutions Sfax";
  }

  String et_Janvier_2023_Mai_2023() {
    return _lang == 'FR' ? "Janvier 2023 - Mai 2023" : "January 2023 - May 2023";
  }

  String et_Description_KMF() {
    return _lang == 'FR' ? "J'ai développé une application pour la gestion des biens immoblieres et loction." : "I developed an application for real estate and rental property management.";
     }

  String et_Stagiaire_2() {
    return _lang == 'FR' ? "Stagiaire 2" : "Intern 2";
  }

  String et_poste() {
    return _lang == 'FR' ? "Agent fenetre dans poste tunisie" : "Window agent in tunisia post office";
  }

  String et_poste_2021() {
    return _lang == 'FR' ? "Juin 2021 - aout 2021" : "June 2021 - August 2021";
  }

  String et_Description_Poste() {
    return _lang == 'FR' ? "gere des movements financier et Ce poste offre une occasion unique de rejoindre une équipe dynamique et de contribuer à l'amélioration continue du service client. Si vous êtes passionné par le service et que vous avez un excellent sens de la communication, nous serions ravis de recevoir votre candidature." : "manages financial and financial movements This position offers a unique opportunity to join a dynamic team and contribute to the continuous improvement of customer service. If you are passionate about service and have excellent communication skills, we would be delighted to receive your application.";
  }

  String et_Stagiaire_1() {
    return _lang == 'FR' ? "Stagiaire 1" : "Intern 1";
  }

  String et_Tunisie_Telecom() {
    return _lang == 'FR' ? "Tunisie Telecom" : "Tunisie Telecom";
  }

  String et_Description_Tunisie_Telecom() {
    return _lang == 'FR' ? "Contribué à l'inscription des clients pour les lignes téléphoniques fixes." : "Contributed to client registration for fixed phone lines.";
  }

    String introt_page1() {
    return _lang == 'FR' ? "Explorez mon parcours professionnel et découvrez mes compétences et expériences à travers cette application." : "Explore my career path and discover my skills and experiences through this application";
  }
  String introt_page2t() {
    return _lang == 'FR' ? "Réalisation de l'Application." : "Application Development";
  }
  String introt_page2b() {
    return _lang == 'FR' ? "L'application a été développée avec le framework Flutter et le langage Dart." : "The application was developed with the Flutter framework and the Dart language.";
  }
    String introt_page3b() {
    return _lang == 'FR' ? "Choisir vos paramètre de départ." : "Choose the starting settings.";
  }
  /*  String ct_Procedures_Douanieres() {
  return _lang == 'FR' ? "Procédures Douanières" : "Customs Procedures";
}

String ct_Controle_documentaire() {
  return _lang == 'FR' ? "Contrôle documentaire" : "Document control";
}*/

  // Textes de la page Compétences
  String cp_Skills() {
    return _lang == 'FR' ? 'Compétences' : 'Skills';
  }
/*
  String cp_Select_skill() {
    return _lang == 'FR' ? 'Sélectionnez une compétence' : 'Select a skill';
  }

  String ct_Classification_tarifaire() {
    return _lang == 'FR' ? "Classification tarifaire" : "Tariff classification";
  }

  String ct_Calculer_droits_taxes() {
    return _lang == 'FR' ? "Calculer les droits de douane et les taxes" : "Calculate customs duties and taxes";
  }

  String ct_Detecter_infractions() {
    return _lang == 'FR' ? "Détecter des infractions" : "Detect infractions";
  }

  String ct_Conseiller_assister_operateurs() {
    return _lang == 'FR' ? "Conseiller et assister les opérateurs économiques" : "Advise and assist economic operators";
  }*/

  String ct_Reseaux_informatique() {
    return _lang == 'FR' ? "Réseaux informatique" : "Computer networks";
  }

  String ct_Configuration_gestion_reseaux() {
    return _lang == 'FR' ? "Configuration et gestion de réseaux" : "Network configuration and management";
  }

  String ct_Protocoles_routage() {
    return _lang == 'FR' ? "Protocoles de routage" : "Routing protocols";
  }

  String ct_Reseaux_LAN_WAN() {
    return _lang == 'FR' ? "Réseaux LAN et WAN" : "LAN and WAN networks";
  }

  String ct_Securite_reseau() {
    return _lang == 'FR' ? "Sécurité réseau" : "Network security";
  }

  String ct_Adressage_IP_subnetting() {
    return _lang == 'FR' ? "Adressage IP et subnetting" : "IP addressing and subnetting";
  }

  String ct_Depannage() {
    return _lang == 'FR' ? "Dépannage" : "Troubleshooting";
  }

  String ct_Depannage_materiel_logiciel() {
    return _lang == 'FR' ? "Dépannage matériel et logiciel" : "Hardware and software troubleshooting";
  }

  String ct_Installation_configuration_systemes_exploitation() {
    return _lang == 'FR' ? "Installation et configuration de systèmes d'exploitation" : "Operating system installation and configuration";
  }

  String ct_Maintenance_materiel_informatique() {
    return _lang == 'FR' ? "Maintenance de matériel informatique" : "Computer hardware maintenance";
  }

  String ct_Support_utilisateurs() {
    return _lang == 'FR' ? "Support aux utilisateurs" : "User support";
  }

  String ct_Development() {
    return _lang == 'FR' ? "Développement" : "Development";
  }

  String ct_Developpement_logiciels() {
    return _lang == 'FR' ? "Développement de logiciels (Python)" : "Software development (Python)";
  }

  String ct_Developpement_web() {
    return _lang == 'FR' ? "Développement Web (HTML, CSS, JavaScript)" : "Web development (HTML, CSS, JavaScript)";
  }

  String ct_Developpement_mobiles() {
    return _lang == 'FR' ? "Développement mobiles (Flutter)" : "Mobile development (Flutter)";
  }

  String ct_Base_de_donnees() {
    return _lang == 'FR' ? "Base de données" : "Database";
  }

  String ct_SQL() {
    return _lang == 'FR' ? "SQL" : "SQL";
  }

  String ct_Traitement_donnees_massive() {
    return _lang == 'FR' ? "Traitement de données massive (Hadoop)" : "Big data processing (Hadoop)";
  }

  String ct_Administration_System() {
    return _lang == 'FR' ? "Administration System" : "System administration";
  }

  String ct_Gestion_systemes_exploitation() {
    return _lang == 'FR' ? "Gestion des systèmes d'exploitation" : "Operating system management";
  }

  String ct_Installation_configuration_serveurs() {
    return _lang == 'FR' ? "Installation et configuration de serveurs" : "Server installation and configuration";
  }

  String ct_Securite_informatique() {
    return _lang == 'FR' ? "Sécurité informatique" : "Information security";
  }

  String ct_Virtualisation_cloud_computing() {
    return _lang == 'FR' ? "Virtualisation et cloud computing" : "Virtualization and cloud computing";
  }

  String ct_Langue() {
    return _lang == 'FR' ? "Langue" : "Language";
  }

  String ct_Arabe() {
    return _lang == 'FR' ? "Arabe" : "Arabic";
  }

  String ct_Francais() {
    return _lang == 'FR' ? "Français" : "French";
  }

  String ct_Anglais() {
    return _lang == 'FR' ? "Anglais" : "English";
  }
  
  // Textes de la page EducationPage
  String ep_Parcours_educatif() {
    return _lang == 'FR' ? 'Parcours éducatif' : 'Educational Background';
  }

  String ep_Master_pro() {
    return _lang == 'FR'
        ? 'Master professionnel en Développement des Systèmes Informatiques et Réseaux'
        : 'Professional Master in Development of Computer Systems and Networks';
  }

  String ep_Institut_Sfax() {
    return _lang == 'FR'
        ? 'Institut Supérieur des Etudes Technologiques de Sfax'
        : 'Higher Institute of Technological Studies of Sfax';
  }

  String ep_En_cours() {
    return _lang == 'FR' ? 'En cours...' : 'In progress...';
  }


  String ep_Licence_administration() {
    return _lang == 'FR'
        ? 'Licence en informatique de gestion'
        : 'Bachelor degree in management IT';
  }

  String ep_Institut() {
    return _lang == 'FR'
        ? 'Institut Supérieur d\'adminstration des affaires Sfax'
        : 'Higher Institute of Business Administration Sfax';
  }

  String ep_Baccalaureat_informatique() {
    return _lang == 'FR' ? 'Baccalauréat en Informatique' : 'High School Diploma in IT';
  }

  String ep_Lycee() {
    return _lang == 'FR' ? 'Lycée El SOUASSI - Mahdia' : 'El SOUASSI High School - Mahdia';
  }

}
