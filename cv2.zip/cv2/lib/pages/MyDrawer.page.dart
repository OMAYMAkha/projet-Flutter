import 'package:cv2/pages/langue/langue_.dart';
import 'package:cv2/theme/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class MyDrawer extends StatefulWidget {
  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  Langue _language = Langue();
  String _selectedLanguage = 'FR';
  final String facebookUrl = 'https://www.facebook.com';
  final String linkedinUrl = 'https://www.linkedin.com';

  @override
  void initState() {
    super.initState();
    _loadSelectedLanguage();
  }

  _loadSelectedLanguage() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _selectedLanguage = prefs.getString('language') ?? 'FR';
    });
  }

  _setSelectedLanguage(String language) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', language);
    setState(() {
      _selectedLanguage = language;
    });
    Provider.of<Langue>(context, listen: false).setLangue(language);
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Container(
          color: Colors.indigo[50],
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              Container(
                height: 200,
                color: Colors.indigo[50],
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      CircleAvatar(
                        backgroundImage: AssetImage("images/profile.jpg"),
                        radius: 50,
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Omayma ben khalifa ",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.location_on,
                            color: Colors.black,
                          ),
                          SizedBox(width: 2),
                          Text(
                            "Sfax",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16,
                              fontWeight: FontWeight.bold
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              ExpansionTile(
                title: Text(
                  Provider.of<Langue>(context).dt_Choisirlalangue(),
                  style: TextStyle(color: Colors.black),
                ),
                leading: Icon(Icons.language, color: Colors.black),
                children: [
                  ListTile(
                    leading: Image.asset('images/francais.png', width: 30, height: 30),
                    title: Text(
                      'FR', 
                      style: TextStyle(
                        color: _selectedLanguage == 'FR' ? Colors.grey : Colors.black
                      ),
                    ),
                    onTap: () {
                      _setSelectedLanguage('FR');
                    },
                  ),
                  ListTile(
                    leading: Image.asset('images/anglais.png', width: 30, height: 30),
                    title: Text(
                      'EN', 
                      style: TextStyle(
                        color: _selectedLanguage == 'EN' ? Colors.grey : Colors.black
                      ),
                    ),
                    onTap: () {
                      _setSelectedLanguage('EN');
                    },
                  ),
                ],
              ),
              ListTile(
                leading: Icon(Icons.brightness_6, color: Colors.black),
                title: Text(
                  Provider.of<Langue>(context).dt_Mode_sombre_clair(),
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () {
                  Provider.of<ThemeProvider>(context, listen: false).toggletheme();
                },
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: Divider(color: Colors.grey),
              ),
              SizedBox(height: 20),
              ListTile(
                leading: Image.asset('images/facebook.png', width: 30, height: 30),
                title: Text('Facebook', style: TextStyle(color: Colors.black)),
                onTap: () => _launchURL(facebookUrl),
              ),
              ListTile(
                leading: Image.asset('images/linkedin.png', width: 30, height: 30),
                title: Text('LinkedIn', style: TextStyle(color: Colors.black)),
                onTap: () => _launchURL(linkedinUrl),
              ),
              ListTile(
                leading: Image.asset('images/appel.png', width: 30, height: 30),
                title: Text(
                  Provider.of<Langue>(context).dt_Telephone(),
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () => _launchPhone('+21621914766'),
              ),
              ListTile(
                leading: Image.asset('images/gmail.png', width: 30, height: 30),
                title: Text('Gmail', style: TextStyle(color: Colors.black)),
                onTap: () => _openEmailApp('omaymakhalifa@gmail.com'),
              ),
              ListTile(
                leading: Image.asset('images/google_maps.png', width: 30, height: 30),
                title: Text(
                  Provider.of<Langue>(context).dt_Adresse(),
                  style: TextStyle(color: Colors.black),
                ),
                onTap: () => MyMap.launchMap(35.506547, 11.047679),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _launchPhone(String phoneNumber) async {
    String url = 'tel:$phoneNumber';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Impossible de lancer $url';
    }
  }

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Impossible d\'ouvrir $url';
    }
  }
}

void _openEmailApp(String mail) async {
  final Uri emailLaunchUri = Uri(
    scheme: 'mailto',
    path: mail,
  );

  if (await canLaunch(emailLaunchUri.toString())) {
    await launch(emailLaunchUri.toString());
  } else {
    throw 'Erreur $emailLaunchUri';
  }
}

class MyMap {
  static void launchMap(double latitude, double longitude) async {
    String googleMapsUrl = 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    if (await canLaunch(googleMapsUrl)) {
      await launch(googleMapsUrl);
    } else {
      throw 'Impossible d\'ouvrir Google Maps';
    }
  }
}
