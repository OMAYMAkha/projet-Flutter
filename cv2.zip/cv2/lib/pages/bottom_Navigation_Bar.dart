import 'package:cv2/pages/langue/langue_.dart';
import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:provider/provider.dart';

class BottomNavigationBarWidget extends StatelessWidget {
  final int selectedIndex;
  final Function(int) onTabChanged;

  const BottomNavigationBarWidget({
    required this.selectedIndex,
    required this.onTabChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.primary,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 4.0, vertical: 15),
      
        child: GNav(
          
          backgroundColor: Theme.of(context).colorScheme.primary,
          
          color:  Colors.white,
          //tabShadow: [BoxShadow(color: Colors.grey.withOpacity(0.5), blurRadius: 8)], // tab button shadow
          activeColor: Theme.of(context).colorScheme.primary,
          tabActiveBorder: Border.all(color: Theme.of(context).colorScheme.tertiary, width: 1), 
          tabBackgroundColor: Colors.white,
          gap: 8,
          padding: EdgeInsets.all(16),
          tabs: [
      
            GButton(
              icon: Icons.home_outlined,
              
              text: Provider.of<Langue>(context).Bt_accueil(),
              onPressed: () => onTabChanged(0),
            ),
            GButton(
              icon: Icons.school_outlined,
              text: 'Education',
              onPressed: () => onTabChanged(1),
            ),
            GButton(
              icon: Icons.work_outline,
              text: 'Experience',
              onPressed: () => onTabChanged(2),
            ),
            /*GButton(
              icon: Icons.contact_emergency_outlined,
              text: 'Contact',
              onPressed: () => onTabChanged(3),
            ),*/
                        GButton(
              icon: Icons.highlight_outlined,
              text: Provider.of<Langue>(context).Bt_competences(),
              onPressed: () => onTabChanged(4),
            ),
          ],
          selectedIndex: selectedIndex,
          onTabChange: onTabChanged,
        ),
      ),
    );
  }
}
