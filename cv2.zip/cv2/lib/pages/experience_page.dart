import 'package:cv2/pages/langue/langue_.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class ExperiencePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Langue langue = Provider.of<Langue>(context);

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          langue.et_Experience_Professionnelle(),
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          _buildExperienceCard(
            context,
            langue.et_IT(),
            langue.et_informatique_deve(),
            langue.et_juin_2023_novembre2023(),
            langue.et_Description_travaile(),
            Icons.local_police,
          ),
         /* SizedBox(height: 16),
          _buildExperienceCard(
            context,
            langue.et_Assistant_Technique(),
            langue.et_Agora_Informatique(),
            langue.et_Septembre_2013_Decembre_2014(),
            langue.et_Description_Agora(),
            Icons.computer,
          ),
         SizedBox(height: 16),
          _buildExperienceCard(
            context,
            langue.et_Magasinier(),
            langue.et_Confection_Ideale_du_Sud(),
            langue.et_Mars_2013_Septembre_2013(),
            langue.et_Description_Confection(),
            Icons.store,
          ),*/
          SizedBox(height: 16),
          _buildExperienceCard(
            context,
            langue.et_Stagiaire_PFE(),
            langue.et_KMF_Bussines_solution(),
            langue.et_Janvier_2023_Mai_2023(),
            langue.et_Description_KMF(),
            Icons.assignment,
          ),
          SizedBox(height: 16),
          _buildExperienceCard(
            context,
            langue.et_Stagiaire_2(),
            langue.et_poste(),
            langue.et_poste_2021(),
            langue.et_Description_Poste(),
            Icons.network_check,
          ),
          SizedBox(height: 16),
          _buildExperienceCard(
            context,
            langue.et_Stagiaire_1(),
            langue.et_Tunisie_Telecom(),
            '',
            langue.et_Description_Tunisie_Telecom(),
            Icons.phone,
          ),
        ],
      ),
    );
  }

  Widget _buildExperienceCard(
    BuildContext context,
    String title,
    String company,
    String period,
    String description,
    IconData icon,
  ) {
    Langue langue = Provider.of<Langue>(context);

    return GestureDetector(
      onTap: () {
        _showExperienceDialog(context, title, company, period, description, langue);
      },
      child: AnimatedContainer(
        duration: Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        transform: Matrix4.identity()..scale(1.0),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: Icon(icon, size: 40, color: Colors.blue),
            title: Text(
              title,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            subtitle: Text('$company\n$period'),
          ),
        ),
      ),
    );
  }

  void _showExperienceDialog(
    BuildContext context,
    String title,
    String company,
    String period,
    String description,
    Langue langue,
  ) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.info,
      borderSide: BorderSide(color: Colors.blue, width: 2),
      width: 380,
      buttonsBorderRadius: BorderRadius.all(Radius.circular(2)),
      headerAnimationLoop: false,
      animType: AnimType.bottomSlide,
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(company),
            SizedBox(height: 10),
            Text(period),
            SizedBox(height: 16),
            Text(description),
          ],
        ),
      ),
      btnOkOnPress: () {},
    ).show();
  }
}
